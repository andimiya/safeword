'use strict';

const http = require('http');

module.exports.handler = (event, context, callback) => {
  http.get(process.env.PI_ENDPOINT, res => {
    const { statusCode } = res;
    let error;

    if (statusCode !== 200) {
      error = new Error('Request Failed.\n' + `Status Code: ${statusCode}`);
      return callback(error, {
        statusCode,
      });
    }
    res.on('end', () => {
      return callback(error, {
        statusCode,
      });
    });
  });
};

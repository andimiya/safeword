'use strict';

module.exports.handler = (event, context, callback) => {
  console.log('SUP NAO');
  callback(null);
};
